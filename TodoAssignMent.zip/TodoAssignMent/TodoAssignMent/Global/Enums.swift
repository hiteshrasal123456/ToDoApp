//
//  Enums.swift
//  TodoAssignMent
//
//  Created by Hitesh Rasal on 16/09/21.
//

import Foundation
import UIKit
//MARK:- Storyboard
enum Storyboard {
    case main
    var identifier : UIStoryboard {
        switch self {
        case .main:
            return UIStoryboard(name: "Main", bundle:nil)
        }
    }
}

//MARK:- ViewController
enum ViewControllers : String {
    case todoVc
    case addTaskVc
    var identifier : String {
        switch self {
        case .todoVc:
            return "ToDoVC"
        case .addTaskVc:
            return "AddTaskVC"
        }
    }
}
//MARK:- TableViewCell
enum TableViewCell : String {
    case taskCell
    var identifier : String {
        switch self {
        case .taskCell:
            return "TaskCellIdef"
        
        }
    }
}
