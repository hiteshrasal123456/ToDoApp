//
//  ToDoVC.swift
//  TodoAssignMent
//
//  Created by Hitesh Rasal on 16/09/21.
//

import UIKit

enum Task: String {
    case Today
    case Tomorrow
    case Upcoming
}

class ToDoVC: UIViewController {
    
    @IBOutlet weak var tblView: UITableView!
    @IBOutlet weak var taskSegControl: UISegmentedControl!
    
    var vwModelObj = ToDoVM()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configUI()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        if self.taskSegControl.selectedSegmentIndex == 0 {
            fetchAll(type: Task.Today)
        } else if self.taskSegControl.selectedSegmentIndex == 1 {
            fetchAll(type: Task.Tomorrow)
        } else if self.taskSegControl.selectedSegmentIndex == 2 {
            fetchAll(type: Task.Upcoming)
        }
        
    }
    func configUI() {
        self.title = "ToDo"
        tblView.register(UINib(nibName: "TaskCell", bundle: nil), forCellReuseIdentifier: TableViewCell.taskCell.identifier)
       
    }
    
    @IBAction func btnAdd(_ sender: Any) {
        let vc = Storyboard.main.identifier.instantiateViewController(identifier: ViewControllers.addTaskVc.identifier) as! AddTaskVC
        if self.taskSegControl.selectedSegmentIndex == 0 {
            vc.vwModelObj.task = Task.Today
        } else if self.taskSegControl.selectedSegmentIndex == 1 {
            vc.vwModelObj.task = Task.Tomorrow
        } else if self.taskSegControl.selectedSegmentIndex == 2 {
            vc.vwModelObj.task = Task.Upcoming
        }
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
    @IBAction func segControlAct(_ sender: UISegmentedControl) {
        let selectedIndex = sender.selectedSegmentIndex
        switch selectedIndex {
        case 0:
            fetchAll(type: Task.Today)
        case 1:
            fetchAll(type: Task.Tomorrow)
        case 2:
            fetchAll(type: Task.Upcoming)
        default:
            print("default")
        }
    }
    
    func fetchAll(type: Task) {
        DispatchQueue.main.async {
            self.vwModelObj.fetchAllTask(taskType: type)
            self.tblView.reloadData()
        }
    }
}

extension ToDoVC: UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if self.taskSegControl.selectedSegmentIndex == 0 {
           return vwModelObj.allToday?.count ?? 0
        } else if self.taskSegControl.selectedSegmentIndex == 1 {
            return vwModelObj.allTomo?.count ?? 0
        } else if self.taskSegControl.selectedSegmentIndex == 2 {
            return vwModelObj.allUpcom?.count ?? 0
        } else {
            return 0
        }
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tblView.dequeueReusableCell(withIdentifier: TableViewCell.taskCell.identifier) as! TaskCell
        if self.taskSegControl.selectedSegmentIndex == 0 {
            cell.todayTaskObj = vwModelObj.allToday?[indexPath.row]
        } else if self.taskSegControl.selectedSegmentIndex == 1 {
            cell.tomoTaskObj = vwModelObj.allTomo?[indexPath.row]
        } else if self.taskSegControl.selectedSegmentIndex == 2 {
            cell.upcomTaskObj = vwModelObj.allUpcom?[indexPath.row]
        }
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 70
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = Storyboard.main.identifier.instantiateViewController(identifier: ViewControllers.addTaskVc.identifier) as! AddTaskVC
        if self.taskSegControl.selectedSegmentIndex == 0 {
            vc.vwModelObj.task = Task.Today
            vc.vwModelObj.todayTask = vwModelObj.allToday?[indexPath.row]
        } else if self.taskSegControl.selectedSegmentIndex == 1 {
            vc.vwModelObj.task = Task.Tomorrow
            vc.vwModelObj.tomoTask = vwModelObj.allTomo?[indexPath.row]
        } else if self.taskSegControl.selectedSegmentIndex == 2 {
            vc.vwModelObj.task = Task.Upcoming
            vc.vwModelObj.upcomTask = vwModelObj.allUpcom?[indexPath.row]
        }
        vc.vwModelObj.isEdit = true
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
