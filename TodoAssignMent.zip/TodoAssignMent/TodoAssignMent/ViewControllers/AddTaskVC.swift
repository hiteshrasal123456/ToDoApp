//
//  AddTaskVC.swift
//  TodoAssignMent
//
//  Created by Hitesh Rasal on 16/09/21.
//

import UIKit

class AddTaskVC: UIViewController {
    
    @IBOutlet weak var btnDeleteHeight: NSLayoutConstraint!
    @IBOutlet weak var btnUpdateHeight: NSLayoutConstraint!
    @IBOutlet weak var btnAddHeight: NSLayoutConstraint!
    @IBOutlet weak var txtTitle: UITextField!
    @IBOutlet weak var txtDescription: UITextField!
    
    var vwModelObj = AddTaskVM()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        configUI()
    }
    
    func configUI() {
        self.title = "Add Task"
       handleEditAddUI()
    }
    
    func handleEditAddUI() {
        if vwModelObj.isEdit {
            self.btnAddHeight.constant = 0
            self.btnUpdateHeight.constant = 34
            self.btnDeleteHeight.constant = 34
            switch vwModelObj.task {
            case .Today:
                self.txtTitle.text = vwModelObj.todayTask?.title
                self.txtDescription.text = vwModelObj.todayTask?.desc
                
            case .Tomorrow:
                self.txtTitle.text = vwModelObj.tomoTask?.title
                self.txtDescription.text = vwModelObj.tomoTask?.desc
            case .Upcoming:
                self.txtTitle.text = vwModelObj.upcomTask?.title
                self.txtDescription.text = vwModelObj.upcomTask?.desc
            default:
                self.txtTitle.text = ""
                self.txtDescription.text = ""
            }
        } else {
            self.btnAddHeight.constant = 34
            self.btnUpdateHeight.constant = 0
            self.btnDeleteHeight.constant = 0
        }
    }
    
    @IBAction func btnDeleteTask(_ sender: Any) {
        let error = vwModelObj.validationTxtField(title: txtTitle.text ?? "", desc: txtDescription.text ?? "")
        if error == nil {
            deleteTask()
        } else {
            print("error is \(String(describing: error))")
        }
    }
   
    @IBAction func btnUpdateTask(_ sender: Any) {
        let error = vwModelObj.validationTxtField(title: txtTitle.text ?? "", desc: txtDescription.text ?? "")
        if error == nil {
            updateTask()
        } else {
            print("error is \(String(describing: error))")
        }
        
        
        
    }
    @IBAction func btnAddTask(_ sender: Any) {
        let error = vwModelObj.validationTxtField(title: txtTitle.text ?? "", desc: txtDescription.text ?? "")
        if error == nil {
            addTask()
        } else {
            print("error is \(String(describing: error))")
        }
        
    }
    //MARK: Task Methods
    func addTask() {
        vwModelObj.saveTask(title: txtTitle.text!, desc: txtDescription.text!)
        self.navigationController?.popViewController(animated: true)
    }
    func updateTask() {
        if vwModelObj.updateTask(title: txtTitle.text!, desc: txtDescription.text!) {
            DispatchQueue.main.async {
                print("Updated successfully.")
                self.navigationController?.popViewController(animated: true)
            }
        } else {
            print("Failed to update.")
        }
    }
    func deleteTask() {
        if vwModelObj.deleteTask() {
            DispatchQueue.main.async {
                print("Deleted successfully.")
                self.navigationController?.popViewController(animated: true)
            }
        } else {
            print("Failed to delete.")
        }
    }
}

extension AddTaskVC: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
    }
}
