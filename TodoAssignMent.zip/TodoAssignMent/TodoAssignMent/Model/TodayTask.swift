//
//  TodayTask.swift
//  TodoAssignMent
//
//  Created by Hitesh Rasal on 16/09/21.
//

import Foundation

struct TodayTask {
    var title: String
    var desc: String
    var id: UUID
}
