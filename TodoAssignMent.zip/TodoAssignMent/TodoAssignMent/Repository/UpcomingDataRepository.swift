//
//  UpcomingDataRepository.swift
//  TodoAssignMent
//
//  Created by Hitesh Rasal on 16/09/21.
//

import UIKit


import Foundation
import CoreData

protocol UpcomingDataRepo {

    func create(upcomingTask: UpcomingTask)
    func getAll() -> [UpcomingTask]?
    func update(upcomingTask: UpcomingTask) -> Bool
    func delete(id: UUID) -> Bool
}



struct UpcomingDataRepository : UpcomingDataRepo
{
    func create(upcomingTask: UpcomingTask) {

        let cdUpcoming = CDUpcoming(context: PersistentStorage.shared.context)
        cdUpcoming.title = upcomingTask.title
        cdUpcoming.desc = upcomingTask.desc
        cdUpcoming.id = upcomingTask.id

        PersistentStorage.shared.saveContext()


    }

    func getAll() -> [UpcomingTask]? {

        let result = PersistentStorage.shared.fetchManagedObject(managedObject: CDUpcoming.self)

        var upcomingTasks : [UpcomingTask] = []

        result?.forEach({ (cdUpcom) in
            upcomingTasks.append(cdUpcom.convertToUpcomTask())
        })

        return upcomingTasks
    }



    func update(upcomingTask: UpcomingTask) -> Bool {

        let cdUpcoming = getcdUpcom(byIdentifier: upcomingTask.id)
        guard cdUpcoming != nil else {return false}

        cdUpcoming?.title = upcomingTask.title
        cdUpcoming?.desc = upcomingTask.desc
        cdUpcoming?.id = upcomingTask.id

        PersistentStorage.shared.saveContext()
        return true
    }

    func delete(id: UUID) -> Bool {

        let cdUpcoming = getcdUpcom(byIdentifier: id)
        guard cdUpcoming != nil else {return false}

        PersistentStorage.shared.context.delete(cdUpcoming!)
        PersistentStorage.shared.saveContext()
        return true
    }


    private func getcdUpcom(byIdentifier id: UUID) -> CDUpcoming?
    {
        let fetchRequest = NSFetchRequest<CDUpcoming>(entityName: "CDUpcoming")
        let predicate = NSPredicate(format: "id==%@", id as CVarArg)

        fetchRequest.predicate = predicate
        do {
            let result = try PersistentStorage.shared.context.fetch(fetchRequest).first

            guard result != nil else {return nil}

            return result

        } catch let error {
            debugPrint(error)
        }

        return nil
    }

    
}
