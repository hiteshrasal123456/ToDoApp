//
//  TodayDataRepository.swift
//  TodoAssignMent
//
//  Created by Hitesh Rasal on 16/09/21.
//


import Foundation
import CoreData

protocol TodayDataRepo {

    func create(todayTask: TodayTask)
    func getAll() -> [TodayTask]?
    func update(todayTask: TodayTask) -> Bool
    func delete(id: UUID) -> Bool
}



struct TodayDataRepository : TodayDataRepo
{
    func create(todayTask: TodayTask) {

        let cdToday = CDToday(context: PersistentStorage.shared.context)
        cdToday.title = todayTask.title
        cdToday.desc = todayTask.desc
        cdToday.id = todayTask.id

        PersistentStorage.shared.saveContext()


    }

    func getAll() -> [TodayTask]? {

        let result = PersistentStorage.shared.fetchManagedObject(managedObject: CDToday.self)

        var todayTasks : [TodayTask] = []

        result?.forEach({ (cdToday) in
            todayTasks.append(cdToday.convertTotodayTask())
        })

        return todayTasks
    }



    func update(todayTask: TodayTask) -> Bool {

        let cdToday = getcdToday(byIdentifier: todayTask.id)
        guard cdToday != nil else {return false}

        cdToday?.title = todayTask.title
        cdToday?.desc = todayTask.desc
        cdToday?.id = todayTask.id

        PersistentStorage.shared.saveContext()
        return true
    }

    func delete(id: UUID) -> Bool {

        let cdToday = getcdToday(byIdentifier: id)
        guard cdToday != nil else {return false}

        PersistentStorage.shared.context.delete(cdToday!)
        PersistentStorage.shared.saveContext()
        return true
    }


    private func getcdToday(byIdentifier id: UUID) -> CDToday?
    {
        let fetchRequest = NSFetchRequest<CDToday>(entityName: "CDToday")
        let predicate = NSPredicate(format: "id==%@", id as CVarArg)

        fetchRequest.predicate = predicate
        do {
            let result = try PersistentStorage.shared.context.fetch(fetchRequest).first

            guard result != nil else {return nil}

            return result

        } catch let error {
            debugPrint(error)
        }

        return nil
    }

    
}
