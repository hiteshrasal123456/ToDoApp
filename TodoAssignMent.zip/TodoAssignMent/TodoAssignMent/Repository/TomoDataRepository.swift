//
//  TomoDataRepository.swift
//  TodoAssignMent
//
//  Created by Hitesh Rasal on 16/09/21.
//


import Foundation
import CoreData

protocol TomoDataRepo {

    func create(tomoTask: TomoTask)
    func getAll() -> [TomoTask]?
    func update(tomoTask: TomoTask) -> Bool
    func delete(id: UUID) -> Bool
}



struct TomoDataRepository : TomoDataRepo
{
    func create(tomoTask: TomoTask) {

        let cdTomo = CDTomo(context: PersistentStorage.shared.context)
        cdTomo.title = tomoTask.title
        cdTomo.desc = tomoTask.desc
        cdTomo.id = tomoTask.id

        PersistentStorage.shared.saveContext()


    }

    func getAll() -> [TomoTask]? {

        let result = PersistentStorage.shared.fetchManagedObject(managedObject: CDTomo.self)

        var tomoTasks : [TomoTask] = []

        result?.forEach({ (cdTomo) in
            tomoTasks.append(cdTomo.convertTotomoTask())
        })

        return tomoTasks
    }



    func update(tomoTask: TomoTask) -> Bool {

        let cdTomo = getcdTomo(byIdentifier: tomoTask.id)
        guard cdTomo != nil else {return false}

        cdTomo?.title = tomoTask.title
        cdTomo?.desc = tomoTask.desc
        cdTomo?.id = tomoTask.id

        PersistentStorage.shared.saveContext()
        return true
    }

    func delete(id: UUID) -> Bool {

        let cdTomo = getcdTomo(byIdentifier: id)
        guard cdTomo != nil else {return false}

        PersistentStorage.shared.context.delete(cdTomo!)
        PersistentStorage.shared.saveContext()
        return true
    }


    private func getcdTomo(byIdentifier id: UUID) -> CDTomo?
    {
        let fetchRequest = NSFetchRequest<CDTomo>(entityName: "CDTomo")
        let predicate = NSPredicate(format: "id==%@", id as CVarArg)

        fetchRequest.predicate = predicate
        do {
            let result = try PersistentStorage.shared.context.fetch(fetchRequest).first

            guard result != nil else {return nil}

            return result

        } catch let error {
            debugPrint(error)
        }

        return nil
    }

    
}
