//
//  TaskCell.swift
//  TodoAssignMent
//
//  Created by Hitesh Rasal on 16/09/21.
//

import UIKit

class TaskCell: UITableViewCell {

    @IBOutlet weak var lblDesc: UILabel!
    @IBOutlet weak var lblTitle: UILabel!
    
    var todayTaskObj: TodayTask? {
        didSet {
            lblTitle.text = todayTaskObj?.title
            lblDesc.text = todayTaskObj?.desc
        }
    }
    var tomoTaskObj: TomoTask? {
        didSet {
            lblTitle.text = tomoTaskObj?.title
            lblDesc.text = tomoTaskObj?.desc
        }
    }
    var upcomTaskObj: UpcomingTask? {
        didSet {
            lblTitle.text = upcomTaskObj?.title
            lblDesc.text = upcomTaskObj?.desc
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        
    }
    
}
