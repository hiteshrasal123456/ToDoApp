//
//  CDUpcoming+CoreDataClass.swift
//  TodoAssignMent
//
//  Created by Hitesh Rasal on 16/09/21.
//
//

import Foundation
import CoreData

@objc(CDUpcoming)
public class CDUpcoming: NSManagedObject {

}
