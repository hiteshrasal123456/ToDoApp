//
//  CDUpcoming+CoreDataProperties.swift
//  TodoAssignMent
//
//  Created by Hitesh Rasal on 16/09/21.
//
//

import Foundation
import CoreData


extension CDUpcoming {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<CDUpcoming> {
        return NSFetchRequest<CDUpcoming>(entityName: "CDUpcoming")
    }

    @NSManaged public var title: String?
    @NSManaged public var desc: String?
    @NSManaged public var id: UUID?

    func convertToUpcomTask() -> UpcomingTask
    {
        return UpcomingTask(title: self.title!, desc: self.desc!, id: self.id!)
    }
}


