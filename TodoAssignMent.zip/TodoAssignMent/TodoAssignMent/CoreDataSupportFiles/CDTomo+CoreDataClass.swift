//
//  CDTomo+CoreDataClass.swift
//  TodoAssignMent
//
//  Created by Hitesh Rasal on 16/09/21.
//
//

import Foundation
import CoreData

@objc(CDTomo)
public class CDTomo: NSManagedObject {

}
