//
//  CDTomo+CoreDataProperties.swift
//  TodoAssignMent
//
//  Created by Hitesh Rasal on 16/09/21.
//
//

import Foundation
import CoreData


extension CDTomo {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<CDTomo> {
        return NSFetchRequest<CDTomo>(entityName: "CDTomo")
    }

    @NSManaged public var title: String?
    @NSManaged public var desc: String?
    @NSManaged public var id: UUID?

    func convertTotomoTask() -> TomoTask
    {
        return TomoTask(title: self.title!, desc: self.desc!, id: self.id!)
    }
}


