//
//  CDToday+CoreDataProperties.swift
//  TodoAssignMent
//
//  Created by Hitesh Rasal on 16/09/21.
//
//

import Foundation
import CoreData


extension CDToday {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<CDToday> {
        return NSFetchRequest<CDToday>(entityName: "CDToday")
    }

    @NSManaged public var desc: String?
    @NSManaged public var title: String?
    @NSManaged public var id: UUID?

    func convertTotodayTask() -> TodayTask
    {
        return TodayTask(title: self.title!, desc: self.desc!, id: self.id!)
    }
}


