//
//  UpcomingManager.swift
//  TodoAssignMent
//
//  Created by Hitesh Rasal on 16/09/21.
//

import UIKit


struct UpcomingManager {
    
    private let upcomDataRepoObj = UpcomingDataRepository()
    func createUpcomTask(taskObj: UpcomingTask) {
        upcomDataRepoObj.create(upcomingTask: taskObj)
    }
    func fetchAllUpcomTask() -> [UpcomingTask]? {
        return upcomDataRepoObj.getAll()
    }
    func updateUpcomTask(taskObj: UpcomingTask) -> Bool {
        return upcomDataRepoObj.update(upcomingTask: taskObj)
    }
    func deleteUpcomTask(id: UUID) -> Bool {
        return upcomDataRepoObj.delete(id: id)
    }
}
