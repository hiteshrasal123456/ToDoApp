//
//  TomoManager.swift
//  TodoAssignMent
//
//  Created by Hitesh Rasal on 16/09/21.
//

import UIKit

struct TomoManager {
    
    private let tomoDataRepoObj = TomoDataRepository()
    func createTomoTask(taskObj: TomoTask) {
        tomoDataRepoObj.create(tomoTask: taskObj)
    }
    func fetchAllTomoTask() -> [TomoTask]? {
        return tomoDataRepoObj.getAll()
    }
    func updateTomoTask(taskObj: TomoTask) -> Bool {
        return tomoDataRepoObj.update(tomoTask: taskObj)
    }
    func deleteTomoTask(id: UUID) -> Bool {
        return tomoDataRepoObj.delete(id: id)
    }
}
