//
//  TodayManager.swift
//  TodoAssignMent
//
//  Created by Hitesh Rasal on 16/09/21.
//

import UIKit
struct TodayManager {
    
    private let todayDataRepoObj = TodayDataRepository()
    func createTodayTask(taskObj: TodayTask) {
        todayDataRepoObj.create(todayTask: taskObj)
    }
    func fetchAllTodayTask() -> [TodayTask]? {
        return todayDataRepoObj.getAll()
    }
    func updateTodayTask(taskObj: TodayTask) -> Bool {
        return todayDataRepoObj.update(todayTask: taskObj)
    }
    func deleteTodayTask(id: UUID) -> Bool {
        return todayDataRepoObj.delete(id: id)
    }
}
