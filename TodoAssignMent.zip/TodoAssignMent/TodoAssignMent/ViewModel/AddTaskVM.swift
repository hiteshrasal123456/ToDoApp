//
//  AddTaskVM.swift
//  TodoAssignMent
//
//  Created by Hitesh Rasal on 16/09/21.
//

import UIKit

class AddTaskVM {

    var isEdit = false
    var task: Task?
    var todayTask: TodayTask?
    var tomoTask: TomoTask?
    var upcomTask: UpcomingTask?
    let todayManager = TodayManager()
    let tomoManager = TomoManager()
    let upcomManager = UpcomingManager()
   
    func saveTask(title: String, desc:String) {
        let taskType = self.task
        switch taskType {
        case .Today:
            let todayTask = TodayTask(title: title, desc: desc, id: UUID())
            todayManager.createTodayTask(taskObj: todayTask)
        case .Tomorrow:
            let tomoTask = TomoTask(title: title, desc: desc, id: UUID())
            tomoManager.createTomoTask(taskObj: tomoTask)
        case .Upcoming:
            let upcomTask = UpcomingTask(title: title, desc: desc, id: UUID())
            upcomManager.createUpcomTask(taskObj: upcomTask)
        default:
            print("Upcoming")
        }
        
    }
    
    func updateTask(title: String, desc:String) -> Bool {
        let taskType = self.task
        switch taskType {
        case .Today:
            let todayTask = TodayTask(title: title, desc: desc, id: self.todayTask!.id)
            return todayManager.updateTodayTask(taskObj: todayTask)
        case .Tomorrow:
            let tomoTask = TomoTask(title: title, desc: desc, id: self.tomoTask!.id)
            return tomoManager.updateTomoTask(taskObj: tomoTask)
        case .Upcoming:
            let upcomTask = UpcomingTask(title: title, desc: desc, id: self.upcomTask!.id)
            return upcomManager.updateUpcomTask(taskObj: upcomTask)
        default:
            return false
        }
        
    }
    
    func deleteTask() -> Bool {
        let taskType = self.task
        switch taskType {
        case .Today:
            return todayManager.deleteTodayTask(id: todayTask!.id)
        case .Tomorrow:
           return tomoManager.deleteTomoTask(id: self.tomoTask!.id)
        case .Upcoming:
            return upcomManager.deleteUpcomTask(id: self.upcomTask!.id)
        default:
            return false
        }
    }
    
    func validationTxtField(title: String, desc: String) -> String? {
        if title.count == 0 {
            return "Please enter title"
        } else if desc.count == 0 {
            return "Please enter description"
        } else {
            return nil
        }
    }
}
