//
//  TodoVM.swift
//  TodoAssignMent
//
//  Created by Hitesh Rasal on 16/09/21.
//

import UIKit

class ToDoVM {

    var allToday:[TodayTask]?
    var allTomo:[TomoTask]?
    var allUpcom:[UpcomingTask]?
    let todayManager = TodayManager()
    let tomoManager = TomoManager()
    let upcomManager = UpcomingManager()
    
    func fetchAllTask(taskType: Task) {
        switch taskType {
        case .Today:
            if let allTodayTask = todayManager.fetchAllTodayTask() {
                self.allToday = allTodayTask
            }
        case .Tomorrow:
            if let allTomoTask = tomoManager.fetchAllTomoTask() {
                self.allTomo = allTomoTask
            }
        case .Upcoming:
            if let allUpcomTask = upcomManager.fetchAllUpcomTask() {
                self.allUpcom = allUpcomTask
            }
      }

    }
}
